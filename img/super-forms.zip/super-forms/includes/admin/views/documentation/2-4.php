<p>
	If you need to edit a form you can do so by navigating to: <strong>Super Forms > Your Forms</strong> and clicking on "Edit" or clicking on the title of the form.<br />
	If you are already editing a form you can also switch between forms from the top left dropdown.
</p>
<table>
	<tr>
		<th>Edit form from list</th>
		<th>Switch to different form (when on form builder page)</th>
	</tr>
	<tr>
		<td><img src="<?php echo $folder; ?>2.4.1.PNG" /></td>
		<td><img src="<?php echo $folder; ?>2.4.2.PNG" /></td>
	</tr>
	<tr>
		<td>To edit a form you can either click on the Edit button or on the form Title</td>
		<td>Switch instantly between forms from the top left dropdown</td>
	</tr>
</table>

<p>
	After clicking on Edit or the form Title you will be redirected to the form builder page with all the elements and settings of the form.
</p>