<p>
	Cloning (copying/duplicating) a form comes in handy whenever you need to create a form that looks almost the same as a form you already created in the past.<br />
	Or when you need a specific part of the form in a new form<br />
	You can clone a form by clicking on "Duplicate" when you are on the page <strong>Super Forms > Your Forms</strong>.
</p>
<table>
	<tr>
		<th>Cloning an existing form</th>
	</tr>
	<tr>
		<td><img src="<?php echo $folder; ?>2.5.1.PNG" /></td>
	</tr>
	<tr>
		<td>After cloning the form you will be automatically redirected to the form builder to start editing the cloned form</td>
	</tr>
</table>