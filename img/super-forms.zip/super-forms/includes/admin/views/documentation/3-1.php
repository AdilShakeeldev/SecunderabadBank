<p>
	To change the default settings you can go to: <strong>Super Forms > Settings</strong> <i>(see picture below)</i><br />
	<img src="<?php echo $folder; ?>3.1.1.PNG" />
</p>
