<p>
	To change the form settings you can go and edit the form and open up "Form Settings" <i>(see picture below)</i><br />
	We have divided the settings into categories. You can choose a category from the dropdown <i>(notice the red arrow pointing towards it)</i>
	<img src="<?php echo $folder; ?>3.2.1.PNG" />
</p>
