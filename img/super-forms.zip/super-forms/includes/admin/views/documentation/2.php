<p>
	To start (<a href="#">receiving emails</a>) and saving information from form submissions (<a href="#">contact entries</a>) you will have to <a href="#doc-2.1">setup your first from</a>.
</p>
<p>
	To help you out and make life easier for you, I have created a <a href="#">Marketplace</a> section where you can find example forms that can be installed with just one click on a button.
	If you want you can even share forms that you have created, and even sell them for a small price. I hope we can create a large database this way with usefull forms that everyone can use for their projects.
</p>